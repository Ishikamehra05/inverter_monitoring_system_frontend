import { z } from "zod";
import { metricSchema, paginationSchema } from "./common";

export const monitorUserSchema = z.object({
  id: z.union([z.string(), z.number()]),
  account: z.string(),
  affiliation: z.string(),
  power: metricSchema,
  today: metricSchema,
  total: metricSchema,
  status: z.object({
    online: z.number(),
    abnormal: z.number(),
    standby: z.number(),
    offline: z.number(),
  }),
});

export type MonitorUsersExportResponse = string;

export const monitorFiltersSchema = z.object({
  status: z.string(),
  sortBy: z.string(),
  sortOrder: z.string(),
  searchUser: z.string(),
  searchSN: z.string(),
  searchInstallationDate: z.string(),
  searchAffiliation: z.string(),
});

export const monitorUsersResponseSchema = z.object({
  items: z.array(monitorUserSchema),
  statusCounts: z.object({
    online: z.number(),
    abnormal: z.number(),
    standby: z.number(),
    offline: z.number(),
  }),
  pagination: paginationSchema,
  filters: monitorFiltersSchema,
});

export interface UpdateProfileRequest {
  phone?: string;
  address?: string;
  timezone?: string;
  email?: string;
}

export interface UpdateProfileResponse {
  success: boolean;
  message: string;
  data: {
    account: string;
    email: string | null;
    phone: string | null;
    address: string | null;
    timezone: string | null;
    updatedAt: string;
  };
}

export interface RelateUserRequest {
  account: string;
  serialNumber: string;
}

export interface RelateUserResponse {
  success: boolean;
  message: string;
  data: {
    account: string;
    serialNumber: string;
  };
}
export interface MonitorUserStatusCountsResponse {
  success: boolean;
  message: string;
  data: {
    loginUser: {
      id: string;
      account: string;
      role: string;
    };
    statusCounts: {
      all: number;
      online: number;
      abnormal: number;
      standby: number;
      offline: number;
    };
    updatedAt: string;
  };
}
export type DeleteAccountRequest = {
  account: string;
};

export type DeleteAccountResponse = {
  success: boolean;
  message: string;
};
export const profileSchema = z.object({
  account: z.string(),
  email: z.string(),
  phone: z.string().optional(),
  address: z.string().optional(),
  timezone: z.string(),
});

export const firmwareSchema = z.object({
  id: z.string(),
  name: z.string(),
  chipType: z.string().optional(),
  version: z.string(),
  createdTime: z.string(),
  remark: z.string(),
});

export const taskSchema = z.object({
  id: z.union([z.string(), z.number()]),
  name: z.string(),
  status: z.string(),
  created: z.string(),
  begin: z.string(),
});

export const createMonitorUserPayloadSchema = z.object({
  account: z.string(),
  password: z.string(),
  confirmPassword: z.string(),
  email: z.string(),
  phone: z.string(),
  timezone: z.string(),
});

export const createdMonitorUserSchema = z.object({
  id: z.union([z.string(), z.number()]),
  account: z.string(),
  email: z.string(),
  phone: z.string(),
  timezone: z.string(),
  role: z.string(),
  portal: z.string(),
  status: z.string(),
  createdAt: z.string(),
});

export const assignMonitorUsersPayloadSchema = z.object({
  monitorUserIds: z.array(z.string()),
  assignedToUserId: z.string(),
});

export const assignMonitorUsersResponseSchema = z.object({
  assignedToUserId: z.string(),
  monitorUserIds: z.array(z.string()),
  assignedCount: z.number(),
  updatedAt: z.string(),
});

export const upgradeJobCommandLogSchema = z.object({
  step: z.number(),
  commandSent: z.string(),
  rawResponse: z.string().nullable(),
  parsedResult: z.string().nullable(),
  status: z.string(),
  sentAt: z.string(),
  respondedAt: z.string().nullable(),
});

export const upgradeJobSchema = z.object({
  jobId: z.string(),
  plantId: z.string(),
  loggerImei: z.string(),
  inverterSerialNo: z.string(),
  currentFirmware: z.string().nullable(),
  newFirmwareVersion: z.string(),
  firmwareId: z.string().nullable(),
  chipType: z.string(),
  updateType: z.string(),
  firmwareUrl: z.string(),
  status: z.string(),
  message: z.string(),
  failureReason: z.string().nullable(),
  stepDeadlineAt: z.string(),
  createdAt: z.string(),
  updatedAt: z.string(),
  commandLog: z.array(upgradeJobCommandLogSchema),
});

export const upgradeTaskDetailSchema = z.object({
  taskId: z.string(),
  name: z.string(),
  status: z.string(),
  createdAt: z.string(),
  updatedAt: z.string(),
  jobs: z.array(upgradeJobSchema),
});

export type AssignMonitorUsersPayload = z.infer<typeof assignMonitorUsersPayloadSchema>;
export type AssignMonitorUsersResponse = z.infer<typeof assignMonitorUsersResponseSchema>;
export type CreateMonitorUserPayload = z.infer<typeof createMonitorUserPayloadSchema>;
export type UpgradeTaskDetail = z.infer<typeof upgradeTaskDetailSchema>;
export type CreatedMonitorUser = z.infer<typeof createdMonitorUserSchema>;
export type MonitorUser = z.infer<typeof monitorUserSchema>;
export type Profile = z.infer<typeof profileSchema>;
export type Firmware = z.infer<typeof firmwareSchema>;
export type ServiceTask = z.infer<typeof taskSchema>;
export type MonitorFilters = z.infer<typeof monitorFiltersSchema>;
export type UpgradeJob = z.infer<typeof upgradeJobSchema>;
